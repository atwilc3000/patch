#ifndef SVNREV_H
#define SVNREV_H
#define SVNREV "58"
#define SVNURL "http://svn.corp.atmel.com/repo/wifi/iotkorea/team-system/wilc3000/trunk"
#endif
